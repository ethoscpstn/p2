<?php
// mail_config.php
return [
    'host' => 'sandbox.smtp.mailtrap.io',
    'username' => 'c1e13c8b555518', // your Gmail
    'password' => '643ad50f0f1141',    // app password
    'port' => 2525,
    'from' => 'test@hanapbahay.local',
    'from_name' => 'HanapBahay Test'
];
