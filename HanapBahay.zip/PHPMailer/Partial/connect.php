<?php

$con=new mysqli('sql204.infinityfree.com','if0_38235707','uPbLyRx5HUJK26O','if0_38235707_dbhanapbahay');
if(!$con){
	die(mysqli_error($con));
}

?>

