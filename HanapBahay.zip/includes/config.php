<?php
if (!defined('ML_BASE')) {
    define('ML_BASE', 'https://revolvingly-uncombining-genia.ngrok-free.dev');
}
if (!defined('ML_KEY')) {
    define('ML_KEY',  'hanapbahay_ml_secure_2024_permanent_key_v1');
}
