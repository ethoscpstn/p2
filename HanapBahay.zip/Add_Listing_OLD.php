<?php
// DEPRECATED: This file is kept for reference only
// All add listing functionality has moved to DashboardAddUnit.php
// Redirect to new form
header("Location: DashboardAddUnit.php");
exit();
?>
