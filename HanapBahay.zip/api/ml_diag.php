<?php
header('Content-Type: application/json');
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/ml_client.php';

$out = [];
$out['env'] = ['ML_BASE'=>ML_BASE, 'ML_KEY_len'=>strlen(ML_KEY)];

$out['version'] = ml_version(ML_BASE);                       // no key
$out['health']  = ml_health(ML_BASE, ML_KEY);                // requires key

$sample = [[
  "Capacity"=>3, "Bedroom"=>1, "unit_sqm"=>24, "cap_per_bedroom"=>3,
  "Type"=>"Apartment","Kitchen"=>"Yes","Kitchen type"=>"Shared",
  "Gender specific"=>"Mixed","Pets"=>"Allowed","Location"=>"Makati"
]];
$out['predict'] = ml_predict($sample, ML_BASE, ML_KEY);
$out['interval']= ml_price_interval($sample, ML_BASE, ML_KEY, 0.08);

echo json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
