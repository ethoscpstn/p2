<?php
/**
 * DEPRECATED FILE - Redirect to new form
 *
 * This file has been replaced by DashboardAddUnit.php which includes:
 * - ML price prediction
 * - All property attributes (bedroom, unit_sqm, kitchen, etc.)
 * - Amenities selection
 * - File uploads (government ID, property photos)
 * - Better validation and UX
 *
 * Backup saved in Add_Listing_BACKUP.php
 */

session_start();
header("Location: DashboardAddUnit.php");
exit();
?>
